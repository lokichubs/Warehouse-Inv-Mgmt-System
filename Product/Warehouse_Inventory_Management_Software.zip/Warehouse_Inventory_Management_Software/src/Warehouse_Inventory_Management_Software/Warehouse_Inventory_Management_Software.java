package Warehouse_Inventory_Management_Software;
public class Warehouse_Inventory_Management_Software {
    /**
     * @param args the command line arguments
     */ 
    public static void main(String[] args) {     
    }
    
}
